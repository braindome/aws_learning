/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./functions/getDogs/index.js":
/*!************************************!*\
  !*** ./functions/getDogs/index.js ***!
  \************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("const { sendResponse } = __webpack_require__(/*! ../../responses/index */ \"./responses/index.js\");\n\nvar dogs = [\n  {\n    id: 549763,\n    breed: \"Labrador Retriever\",\n    age: 5,\n    color: \"Golden\",\n    weight_kg: 30,\n  },\n  {\n    id: 485923,\n    breed: \"German Shepherd\",\n    age: 3,\n    color: \"Black and Tan\",\n    weight_kg: 35,\n  },\n  {\n    id: 872721,\n    breed: \"Poodle\",\n    age: 2,\n    color: \"White\",\n    weight_kg: 10,\n  },\n];\n\nexports.handler = async (event, context) => {\n\n    return sendResponse(200, {dogs})\n};\n\n\n//# sourceURL=webpack://dog-api-serverless/./functions/getDogs/index.js?");

/***/ }),

/***/ "./responses/index.js":
/*!****************************!*\
  !*** ./responses/index.js ***!
  \****************************/
/***/ ((module) => {

eval("function sendResponse(code, response) {\n  return {\n    statusCode: code,\n    headers: {\n      \"Content-Type\": \"application/json\",\n    },\n    body: JSON.stringify(response),\n  };\n}\n\nmodule.exports = { sendResponse };\n\n\n//# sourceURL=webpack://dog-api-serverless/./responses/index.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./functions/getDogs/index.js");
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;